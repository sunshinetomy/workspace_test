namespace MusicXml.Domain
{
	public class Forward
	{
		public int Duration { get; set; }
	}
}