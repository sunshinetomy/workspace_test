namespace MusicXml.Domain
{
	public class Backup
	{
		public int Duration { get; set; }
	}
}