MusicXml.Net
============

Now parsing MusicXml is easy in .NET! Simply call MusicXmlParser.GetScore with your file location and enjoy!

var score = MusicXmlParser.GetScore("Your file URI");

With your score in hand you can have access to most of the features of MusicXml notation.
